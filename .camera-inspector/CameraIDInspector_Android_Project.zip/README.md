# Camera ID Inspector — Android (Java, no third-party libraries)

A small privacy-friendly Android app designed to enumerate Camera2 camera IDs, logical/physical multi-camera groups, and supported characteristics. Useful for identifying cameras exposed to third-party apps such as LMC 8.4 GCam.

## Permissions and privacy
- Requests **Camera** permission only (to view camera characteristics on supported Android versions).
- Does not open the camera, take photos, record audio, access storage, or connect to the internet.
- Results stay on your phone until you use Copy/Share Report.
- No internet permission and no third-party analytics libraries.

## Build an APK on GitHub (no computer required)
1. Create a **private** GitHub repository and upload the files in this ZIP, preserving folders. Important: the `.github/workflows/build-apk.yml` workflow must be included. GitHub's mobile website can use a desktop-mode browser for easier uploads; if uploading individual files is difficult, use GitHub Desktop or a PC.
2. Open your repo's **Actions** tab, choose **Build Camera ID Inspector APK**, and run the workflow, or push to `main`/`master` to trigger it automatically.
3. Open the successful workflow run's **Artifacts** section and download **CameraIDInspector-debug-APK**. Extract its ZIP to get `app-debug.apk`.
4. Install the APK on your Android phone, granting permission to install from the app you downloaded it with (if prompted).
5. Grant the Camera permission. Tap **SCAN CAMERAS**, then **COPY FULL REPORT** and paste the result into ChatGPT.

Android Studio alternative: open this folder as a project, let Gradle sync, and choose **Build > Build APK(s)**. Debug output is `app/build/outputs/apk/debug/app-debug.apk`.

## What is covered
- App-visible Camera2 IDs (`CameraManager.getCameraIdList()`)
- Logical-multi-camera groups and `getPhysicalCameraIds()` (Android API 28+)
- For each accessible logical or physical ID: facing, focal lengths, apertures, sensor active array / physical size, ISO range, Camera2 hardware level, RAW and logical multi-camera capabilities, and the largest supported JPEG output resolution.

## Important Android limitation
Android does **not** have to expose every physical lens to third-party apps. A physical ID may be present in a logical camera group but not separately openable. Some sensors may be entirely hidden by the OEM camera HAL; this app cannot discover inaccessible IDs, nor bypass device/vendor restrictions. Camera IDs may be different from indexes inside LMC's configuration.

## Technical
Package name: `com.cameraid.inspector`  
Min API: 28 (Android 9) · Target API: 34 · Compile API: 35.  
Build: Android Gradle Plugin 8.6.1, Gradle 8.9, JDK 17.  
No runtime dependencies besides the Android platform.
