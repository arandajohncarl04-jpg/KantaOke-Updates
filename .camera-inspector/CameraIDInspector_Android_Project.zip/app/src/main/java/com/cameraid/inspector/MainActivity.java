package com.cameraid.inspector;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Bundle;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION_CODE = 7201;
    private static final int BG = Color.rgb(16, 19, 23);
    private static final int PANEL = Color.rgb(29, 35, 40);
    private static final int GREEN = Color.rgb(111, 218, 148);
    private static final int WHITE = Color.rgb(238, 244, 240);
    private static final int MUTED = Color.rgb(171, 187, 179);
    private TextView resultView;
    private String report = "Not scanned yet.";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(BG);
        main.setPadding(dp(18), dp(22), dp(18), dp(12));
        setContentView(main);

        TextView title = text("CAMERA ID INSPECTOR", 22, GREEN, true);
        main.addView(title);
        TextView intro = text("Camera2 • Logical & physical lens mapping", 13, MUTED, false);
        intro.setPadding(0, dp(4), 0, dp(15));
        main.addView(intro);

        Button scan = button("SCAN CAMERAS", true);
        scan.setOnClickListener(v -> checkAndScan());
        main.addView(scan);
        Button copy = button("COPY FULL REPORT", false);
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Camera2 report", report));
                Toast.makeText(this, "Report copied", Toast.LENGTH_SHORT).show();
            }
        });
        main.addView(copy);
        Button share = button("SHARE REPORT", false);
        share.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, report);
            startActivity(Intent.createChooser(i, "Share camera report"));
        });
        main.addView(share);

        TextView notice = text("No photos or videos recorded. No internet permission. Some lenses may be hidden by Android.", 12, MUTED, false);
        notice.setPadding(dp(3), dp(12), dp(3), dp(12));
        main.addView(notice);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout.LayoutParams scrollP = new LinearLayout.LayoutParams(-1, 0, 1f);
        main.addView(scroll, scrollP);
        resultView = text("Tap SCAN CAMERAS to see your available camera IDs.", 13, WHITE, false);
        resultView.setTypeface(Typeface.MONOSPACE);
        resultView.setTextIsSelectable(true);
        resultView.setPadding(dp(12), dp(15), dp(12), dp(18));
        GradientDrawable panel = new GradientDrawable();
        panel.setColor(PANEL);
        panel.setCornerRadius(dp(12));
        resultView.setBackground(panel);
        scroll.addView(resultView);
        checkAndScan();
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? BG : WHITE);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(primary ? GREEN : PANEL);
        shape.setCornerRadius(dp(10));
        b.setBackground(shape);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.bottomMargin = dp(8);
        b.setLayoutParams(p);
        return b;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void checkAndScan() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            report = "Camera permission is required to inspect complete Camera2 characteristics.\nTap Allow in the permission dialog, then scan again.";
            resultView.setText(report);
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
            return;
        }
        scanCameras();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            scanCameras();
        } else if (requestCode == CAMERA_PERMISSION_CODE) {
            resultView.setText("Camera permission not granted. Open app settings to grant it, or tap Scan Cameras to ask again.");
        }
    }

    private void scanCameras() {
        StringBuilder out = new StringBuilder();
        out.append("CAMERA ID INSPECTOR v1.0\n");
        out.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("----------------------------------\n");
        CameraManager mgr = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        if (mgr == null) {
            report = out.append("Camera service unavailable.\n").toString();
            resultView.setText(report);
            return;
        }
        try {
            String[] ids = mgr.getCameraIdList();
            out.append("APP-VISIBLE CAMERA IDs: ").append(Arrays.toString(ids)).append("\n");
            out.append("Visible camera count: ").append(ids.length).append("\n");
            out.append("==================================\n");
            Set<String> listed = new HashSet<>(Arrays.asList(ids));
            Set<String> physicalSeen = new HashSet<>();
            for (String id : ids) {
                appendCamera(out, mgr, id, "APP-VISIBLE", true);
                try {
                    CameraCharacteristics c = mgr.getCameraCharacteristics(id);
                    Set<String> physical = c.getPhysicalCameraIds();
                    if (!physical.isEmpty()) {
                        out.append("Logical group ").append(id).append(" -> physical IDs: ").append(physical).append("\n");
                    }
                    for (String physicalId : physical) {
                        if (!listed.contains(physicalId) && physicalSeen.add(physicalId)) {
                            appendCamera(out, mgr, physicalId, "PHYSICAL / NOT STANDALONE LISTED", false);
                        }
                    }
                } catch (Exception ex) {
                    out.append("Physical ID check for ").append(id).append(": ").append(ex.getClass().getSimpleName()).append("\n");
                }
            }
            out.append("\nNOTES\n");
            out.append("• App-visible Camera2 IDs may differ from GCam/LMC AUX slots.\n");
            out.append("• A physical ID under a logical camera may not open independently.\n");
            out.append("• Vendor-hidden lenses cannot be enumerated by a normal app.\n");
            out.append("• RAW capability does not guarantee LMC RAW mode works.\n");
            out.append("• Report is generated locally; copy/share only if you choose.\n");
        } catch (CameraAccessException ex) {
            out.append("Camera access error: ").append(ex.getMessage()).append('\n');
        } catch (SecurityException ex) {
            out.append("Permission error: ").append(ex.getMessage()).append('\n');
        } catch (Exception ex) {
            out.append("Unexpected scan error: ").append(ex.getClass().getSimpleName()).append(" ").append(ex.getMessage()).append('\n');
        }
        report = out.toString();
        resultView.setText(report);
    }

    private void appendCamera(StringBuilder out, CameraManager mgr, String id, String label, boolean listed) {
        out.append("\n[CAMERA ID: ").append(id).append("] ").append(label).append('\n');
        try {
            CameraCharacteristics c = mgr.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            out.append("Facing: ").append(facing == null ? "unknown" : facing == CameraCharacteristics.LENS_FACING_BACK ? "BACK" : facing == CameraCharacteristics.LENS_FACING_FRONT ? "FRONT" : "EXTERNAL").append('\n');
            Integer hw = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
            out.append("Camera2 level: ").append(hwLevel(hw)).append('\n');
            Integer orientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (orientation != null) out.append("Sensor orientation: ").append(orientation).append(" deg\n");
            Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (flash != null) out.append("Flash: ").append(flash).append('\n');
            float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            if (focal != null) out.append("Focal lengths: ").append(Arrays.toString(focal)).append(" mm\n");
            float[] apertures = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES);
            if (apertures != null) out.append("Apertures: ").append(Arrays.toString(apertures)).append('\n');
            SizeF physicalSize = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (physicalSize != null) out.append("Sensor size: ").append(String.format(Locale.US, "%.2f x %.2f mm", physicalSize.getWidth(), physicalSize.getHeight())).append('\n');
            android.util.Size pix = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
            if (pix != null) out.append("Pixel array: ").append(pix.getWidth()).append('x').append(pix.getHeight()).append('\n');
            Rect active = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            if (active != null) out.append("Active array: ").append(active.width()).append('x').append(active.height()).append('\n');
            Range<Integer> iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            if (iso != null) out.append("ISO range: ").append(iso.getLower()).append('-').append(iso.getUpper()).append('\n');
            Range<Long> exposure = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            if (exposure != null) out.append("Exposure (ns): ").append(exposure.getLower()).append(" - ").append(exposure.getUpper()).append('\n');
            Integer bayer = c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT);
            if (bayer != null) out.append("Bayer arrangement: ").append(bayerName(bayer)).append('\n');
            int[] capabilities = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            if (capabilities != null) {
                out.append("RAW capability: ").append(has(capabilities, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)).append('\n');
                out.append("Logical multi-camera: ").append(has(capabilities, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)).append('\n');
            }
            Set<String> physical = c.getPhysicalCameraIds();
            if (!physical.isEmpty()) out.append("Physical IDs: ").append(physical).append('\n');
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] sizes = map.getOutputSizes(android.graphics.ImageFormat.JPEG);
                if (sizes != null && sizes.length != 0) {
                    Size max = sizes[0];
                    for (Size s : sizes) if ((long)s.getWidth() * s.getHeight() > (long)max.getWidth() * max.getHeight()) max = s;
                    out.append("Max JPEG: ").append(max.getWidth()).append('x').append(max.getHeight()).append('\n');
                }
            }
            out.append("Listed/openable candidate: ").append(listed).append('\n');
        } catch (Exception ex) {
            out.append("Characteristics unavailable: ").append(ex.getClass().getSimpleName()).append(" — ").append(ex.getMessage()).append('\n');
            out.append("This ID may be a restricted physical sensor.\n");
        }
    }

    private boolean has(int[] values, int needle) {
        for (int v : values) if (v == needle) return true;
        return false;
    }

    private String hwLevel(Integer value) {
        if (value == null) return "unknown";
        if (value == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY) return "LEGACY";
        if (value == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED) return "LIMITED";
        if (value == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL) return "FULL";
        if (value == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3) return "LEVEL_3";
        if (value == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL) return "EXTERNAL";
        return "value " + value;
    }

    private String bayerName(int bayer) {
        switch (bayer) {
            case CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_RGGB: return "RGGB";
            case CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_GRBG: return "GRBG";
            case CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_GBRG: return "GBRG";
            case CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_BGGR: return "BGGR";
            case CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_RGB: return "RGB";
            case CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_MONO: return "MONO";
            default: return "value " + bayer;
        }
    }
}
